/* Write a C program to compare two strings. (Use standard library string functions). 
Example: input: string1: “computer”, string2: “coMpUter”   output: same
input: string1: “ukraine”, string2: “ucraine”  output: not same */

#include <stdio.h>
#include <string.h>
#include <ctype.h>

void toLowerCase(char *str) {
    for (int i = 0; str[i]; i++) {
        str[i] = tolower(str[i]);
    }
}

int main() {
    char string1[100], string2[100];
    
    printf("Enter first string: ");
    fgets(string1, sizeof(string1), stdin);
    printf("Enter second string: ");
    fgets(string2, sizeof(string2), stdin);
    
    string1[strcspn(string1, "\n")] = 0;
    string2[strcspn(string2, "\n")] = 0;
    
    toLowerCase(string1);
    toLowerCase(string2);

    if (strcmp(string1, string2) == 0) {
        printf("Same\n");
    } else {
        printf("Not same\n");
    }
    
    return 0;
}