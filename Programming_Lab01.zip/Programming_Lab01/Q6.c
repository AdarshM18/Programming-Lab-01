/* Write a C program to obtain the values of permutations nPr and combinations nCr, when n and r are given. (n and r denote their usual meaning). */

#include <stdio.h>

int main ()  
{  
    int n, r, per,comb, fact1, fact2, fact3,number,i;
    printf("Enter the Value of n and r: ");
    scanf("%d %d",&n,&r);

    fact1 = n;
    for (int i = n - 1; i >= 1; i--)
    {  
        fact1 = fact1 * i;
    }

    number = n - r;
    fact2 = number;
    for (i = number - 1; i >= 1; i--)
    {  
        fact2 = fact2 * i;
    }

    fact3 = r;
    for (i = r - 1; i >= 1; i--)
    {  
        fact3 = fact3 * i;
    }

    per = fact1 / fact2;
    printf("nPr = %d\n",per);

    comb = fact1/(fact2*fact3);
    printf("nCr = %d",comb);
      
}