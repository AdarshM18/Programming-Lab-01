/* Write an efficient C program to find the largest and the second-largest elements of a given array. 
Example: input: {203, 45, 1, 3, 200, 298},
output: largest: 298, second-largest: 203. */

#include <stdio.h>
#include <limits.h> // For INT_MIN

void findLargestAnd2ndLargest(int arr[], int n, int *largest, int *secondLargest) {

    *largest = INT_MIN;
    *secondLargest = INT_MIN;

    for (int i = 0; i < n; i++) {
        if (arr[i] > *largest) {
            *secondLargest = *largest;
            *largest = arr[i];
        } else if (arr[i] > *secondLargest && arr[i] < *largest) {
            *secondLargest = arr[i];
        }
    }
}

int main() {
    int n;
    printf("Enter the number of elements in the array: ");
    scanf("%d", &n);

    if (n < 2) {
        printf("Array must contain at least two elements.\n");
        return 1;
    }

    int arr[n];
    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    int largest, secondLargest;
    findLargestAnd2ndLargest(arr, n, &largest, &secondLargest);

    if (secondLargest == INT_MIN) {
        printf("There is no second-largest element.\n");
    } else {
        printf("Largest: %d\n", largest);
        printf("Second-largest: %d\n", secondLargest);
    }

    return 0;
}