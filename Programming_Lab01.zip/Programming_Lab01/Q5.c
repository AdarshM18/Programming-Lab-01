/*  Write a C program to calculate the SUM of the following series for a given x and n; where, −1<x≤1,n>100,
SUM =x − x2/2 + x3/3 - x4/4 + ....upto nth term. */

#include <stdio.h>
#include <math.h>

double calculate_series_sum(double x, int n) {
    double sum = 0.0;
    double term;
    
    for (int i = 1; i <= n; i++) {
        term = pow(x, i) / i;
        if (i % 2 == 0) {
            term = -term;
        }
        sum += term;
    }
    
    return sum;
}

int main() {
    double x;
    int n;
    
    printf("Enter the value of x (−1 < x ≤ 1): ");
    scanf("%lf", &x);
    
    if (x <= -1 || x > 1) {
        printf("Invalid input for x. It should be −1 < x ≤ 1.\n");
        return 1;
    }
    
    printf("Enter the value of n (n > 100): ");
    scanf("%d", &n);
    
    if (n <= 100) {
        printf("Invalid input for n. It should be n > 100.\n");
        return 1;
    }
    
    double sum = calculate_series_sum(x, n);
    
    printf("The sum of the series is: %lf\n", sum);
    
    return 0;
}
