// Given two positive integers, write a C program to find out whether two numbers are co-prime.Take numbers from the user externally.

#include<stdio.h>
int hcf(int a,int b);
int main(){
    int a,b;
    printf("Enter 2 positive numbers: \n");
    scanf("%d %d",&a,&b);
    
    if(hcf(a,b)==1){
        printf("%d and %d are Co-prime..",a,b);
    }
    else{
        printf("%d and %d are not Co-prime..",a,b);
    }
    return 0;
}

int hcf(int a,int b){
    if(b!=0){
        return hcf(b,a%b);
    }
    else{
        return a;
    }
}