/* Given two strings: s and t. Return the minimum number of operations required to convert s to t. The possible operations are permitted:
(i) Insert a character at any position of the string.
(ii) Remove any character from the string.
(iii) Replace any character from the string with any other character.
Consider all operations have the exact cost. */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int minDistanceRecursive(const char *s, const char *t, int m, int n) {

    if (m == 0) return n; // If s is empty, need to insert all characters of t
    if (n == 0) return m; // If t is empty, need to delete all characters of s

    if (s[m - 1] == t[n - 1]) {
        return minDistanceRecursive(s, t, m - 1, n - 1);
    }

    int insertCost = minDistanceRecursive(s, t, m, n - 1) + 1; // Insert t[n-1] into s
    int deleteCost = minDistanceRecursive(s, t, m - 1, n) + 1; // Delete s[m-1]
    int replaceCost = minDistanceRecursive(s, t, m - 1, n - 1) + 1; // Replace s[m-1] with t[n-1]

    return (insertCost < deleteCost ? (insertCost < replaceCost ? insertCost : replaceCost) : (deleteCost < replaceCost ? deleteCost : replaceCost));
}

int minDistance(const char *s, const char *t) {
    int m = strlen(s);
    int n = strlen(t);
    return minDistanceRecursive(s, t, m, n);
}

int main() {
    char s[100], t[100];

    printf("Enter the first string (s): ");
    fgets(s, sizeof(s), stdin);
    s[strcspn(s, "\n")] = '\0';

    printf("Enter the second string (t): ");
    fgets(t, sizeof(t), stdin);
    t[strcspn(t, "\n")] = '\0';

    int result = minDistance(s, t);

    printf("The minimum number of operations required to convert '%s' to '%s' is: %d\n", s, t, result);

    return 0;
}