/* A perfect number is a positive integer that is equal to the sum of its positive divisors, excluding the number itself. For instance, 6 has divisors 1, 2 and 3 
(excluding itself), and 1 + 2 + 3 = 6; so 6 is a perfect number.Anumber n is called deficient if the sum of its proper divisors is less than 
n and it is called abundant if this sum exceeds n.For instance, 12 has divisors 1, 2, 3, 4, and 6 (excluding itself), and 1 + 2 + 3 + 4 + 6 = 16; so
12 is an abundant number.
(a) Write a C program to check a given number is a perfect number/deficient/abundant. */

#include <stdio.h>

int sum_of_divisors(int n) {
    int sum = 1; 
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            if (i * i != n) {
                sum += i + n / i; 
            } else {
                sum += i;
            }
        }
    }
    return sum;
}

int main() {
    int n;

    printf("Enter a number: ");
    scanf("%d", &n);
    
    int sum = sum_of_divisors(n);

    if (sum == n) {
        printf("%d is a perfect number.\n", n);
    } else if (sum < n) {
        printf("%d is a deficient number.\n", n);
    } else {
        printf("%d is an abundant number.\n", n);
    }
    
    return 0;
}