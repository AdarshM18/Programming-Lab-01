/* (b) By mathematical analysis, it can be shown that all integers greater than 28123 can be written as the sum of two abundant numbers. 
However, this upper limit cannot be reduced any further by analysis, even though it is known that the greatest number that cannot be expressed as
the sum of two abundant numbers is less than this limit. Find the sum of all the positive integers which cannot be written as the sum of two abundant numbers. */

#include <stdio.h>
#include <stdbool.h>

#define LIMIT 28123

int sum_of_divisors(int n) {
    int sum = 1;
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            if (i * i != n) {
                sum += i + n / i;
            } else {
                sum += i;
            }
        }
    }
    return sum;
}

void find_abundant_numbers(bool abundant[]) {
    for (int i = 12; i <= LIMIT; i++) {
        if (sum_of_divisors(i) > i) {
            abundant[i] = true;
        }
    }
}

void find_sums_of_two_abundant_numbers(bool can_be_written_as_sum[]) {
    bool abundant[LIMIT + 1] = {false};
    find_abundant_numbers(abundant);
    
    for (int i = 1; i <= LIMIT; i++) {
        if (abundant[i]) {
            for (int j = i; j <= LIMIT; j++) {
                if (abundant[j] && i + j <= LIMIT) {
                    can_be_written_as_sum[i + j] = true;
                }
            }
        }
    }
}

int main() {
    bool can_be_written_as_sum[LIMIT + 1] = {false};
    find_sums_of_two_abundant_numbers(can_be_written_as_sum);
    
    int sum_of_non_sums = 0;
    for (int i = 1; i <= LIMIT; i++) {
        if (!can_be_written_as_sum[i]) {
            sum_of_non_sums += i;
        }
    }
    printf("The sum of all positive integers which cannot be written as the sum of two abundant numbers is %d.\n", sum_of_non_sums);
    
    return 0;
}