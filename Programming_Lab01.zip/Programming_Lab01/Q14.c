/* Write a C program that takes n distinct integers as input and stores them in an array such that every ith(0≤i≤(n−1)) element in the array is
bigger than 2×(i+1)th and(2×(i+1)+1)th elements.Printthearray.
Example: input:1,3,15,7,9,6,8
output:15,9,8,1,7,3,6 */

#include <stdio.h>
#include <stdlib.h>

// Function to compare two elements for sorting
int compare(const void *a, const void *b) {
    return (*(int *)b - *(int *)a); // Sort in descending order
}

// Function to rearrange the array according to the given condition
void rearrangeArray(int arr[], int size) {
    // Sort the array in descending order
    qsort(arr, size, sizeof(int), compare);
    
    // Create a temporary array to store the rearranged elements
    int *result = malloc(size * sizeof(int));
    if (result == NULL) {
        perror("Unable to allocate memory");
        exit(EXIT_FAILURE);
    }

    // Rearrange the array
    int pos = 0;
    for (int i = 0; i < size; i++) {
        if (2 * (i + 1) < size) {
            result[i] = arr[pos++];
        } else {
            result[i] = arr[pos++];
        }
    }

    // Copy the rearranged array back to the original array
    for (int i = 0; i < size; i++) {
        arr[i] = result[i];
    }

    free(result);
}

int main() {

    int size;
    int arr[100];
    printf("Enter size of an array: ");
    scanf("%d",&size);

    for(int i=0;i<size;i++){
        scanf("%d",&arr[i]);
    }

    rearrangeArray(arr, size);

    printf("Rearranged array: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    return 0;
}