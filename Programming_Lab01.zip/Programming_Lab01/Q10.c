/* Write a C program to encrypt a string as follows: Replace all the a’s of the string with b.
Example: input: aadhaar, output: bbdhbbr. */

#include <stdio.h>
#define MAX_LENGTH 100

int main() {
    char str[MAX_LENGTH];

    printf("Enter the string to encrypt: ");
    fgets(str, sizeof(str), stdin);

    for (int i = 0; str[i] != '\0'; i++) {
        if (str[i] == 'a') {
            str[i] = 'b';
        }
    }

    printf("Encrypted string: %s\n", str);

    return 0;
}
