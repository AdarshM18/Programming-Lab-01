/* Write a C program that takes the equations (in the form of m and c) of two straight lines and identifies whether they
are parallel, perpendicular, or intersecting with an angle θ != 90o using switch-case.Example: Input: m1 = 1,c1 = 7,
m2 = −1,c2 = 5; Output: perpendicular. Note: Inputs represent the following equations: y = x + 7;y = −x + 5 */

#include <stdio.h>

int main() {
    double m1, c1, m2, c2;
    int relationship;

    printf("Enter the slope (m1) and intercept (c1) of the first line: ");
    scanf("%lf %lf", &m1, &c1);
    
    printf("Enter the slope (m2) and intercept (c2) of the second line: ");
    scanf("%lf %lf", &m2, &c2);

    if (m1 == m2) {
        relationship = 1;
    }
    else if (m1 * m2 == -1) {
        relationship = 2;
    }
    else {
        relationship = 3;
    }
    switch (relationship) {
        case 1:
            printf("The lines are parallel.\n");
            break;
        case 2:
            printf("The lines are perpendicular.\n");
            break;
        case 3:
            printf("The lines intersect with an angle θ != 90°.\n");
            break;
        default:
            printf("Error: Invalid relationship.\n");
            break;
    }

    return 0;
}