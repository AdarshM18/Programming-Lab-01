/* Write a function in C to find the highest frequency element in an array.
Example: input: {1, 3, 5, 1, 7, 5, 4, 3, 1, 3, 5, 5, 4, 5, 1, 5},
output: Element: 5; Frequency: 6. */

#include <stdio.h>
#define MAX_SIZE 100

struct mostFrequent {
    int mostFrequentElement;
    int maxCount;
};

typedef struct mostFrequent Struct;

Struct findMostFrequent(int Arr[], int size) {
    Struct s;
    s.maxCount = 0;
    s.mostFrequentElement = Arr[0];

    for (int i = 0; i < size; i++) {
        int count = 0;
        for (int j = 0; j < size; j++) {
            if (Arr[j] == Arr[i]) {
                count++;
            }
        }

        if (count > s.maxCount) {
            s.maxCount = count;
            s.mostFrequentElement = Arr[i];
        }
    }

    return s;
}

int main() {
    int n;
    int Arr[MAX_SIZE];
    Struct result;

    printf("Enter the size of Array (up to %d): ", MAX_SIZE);
    scanf("%d", &n);

    if (n <= 0 || n > MAX_SIZE) {
        printf("Invalid array size. Must be between 1 and %d.\n", MAX_SIZE);
        return 1;
    }

    printf("Enter %d elements in Array:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &Arr[i]);
    }

    result = findMostFrequent(Arr, n);

    printf("\nElement: %d\nFrequency: %d\n", result.mostFrequentElement, result.maxCount);

    return 0;
}