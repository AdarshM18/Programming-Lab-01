/* A Harshad(or Niven) number with base n is an integer that is divisible by the sum of its digits.
Example: Input: 126; Output: Harshad number.(Reason: 1 + 2 + 6 = 9, and 126 is divisible by 9)
Write a C program that asks to take a number (with base 10) from a user and returns whether it is a Harshad number. */

#include<stdio.h>

int main(){
    int n,d;
    int sum = 0;

    printf("Enter a Number: ");
    scanf("%d",n);
    int a=n;

    while (a!=0)
    {
        d = a%10;
        sum += d;
        a = a/10;
    }

    if (n%sum == 0) printf("Yes");
    else printf("No");
}