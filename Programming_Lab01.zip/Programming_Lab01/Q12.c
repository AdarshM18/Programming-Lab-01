/* You have two sets A and B containing n and m (1 ≤ n,m ≤ 1000) distinct integers, respectively. Implement the following set of operations. 
Write down a separate function for each of the following operations.
(i) The union of two sets A ∪ B.
(ii) The intersection between two sets A ∩ B.
(iii) The set difference A \ B and B \ A
(iv) The symmetric difference A∆B = (A∪B)\(A∩B)
Write down a print function to print the output of each of the above operations. */

#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 1000

void printSet(int set[], int size) {
    for (int i = 0; i < size; i++) {
        printf("%d ", set[i]);
    }
    printf("\n");
}

void unionSets(int A[], int n, int B[], int m) {
    int result[MAX_SIZE];
    int size = 0;

    // Add all elements of A to result
    for (int i = 0; i < n; i++) {
        result[size++] = A[i];
    }

    // Add elements of B to result if not already present
    for (int i = 0; i < m; i++) {
        int j;
        for (j = 0; j < size; j++) {
            if (result[j] == B[i]) break;
        }
        if (j == size) {
            result[size++] = B[i];
        }
    }

    printf("Union of A and B: ");
    printSet(result, size);
}

// Function to find the intersection of two sets
void intersectionSets(int A[], int n, int B[], int m) {
    int result[MAX_SIZE];
    int size = 0;

    // Find common elements
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (A[i] == B[j]) {
                result[size++] = A[i];
                break;
            }
        }
    }

    printf("Intersection of A and B: ");
    printSet(result, size);
}

// Function to find the difference A \ B and B \ A
void setDifference(int A[], int n, int B[], int m) {
    int resultAminusB[MAX_SIZE];
    int resultBminusA[MAX_SIZE];
    int sizeAminusB = 0;
    int sizeBminusA = 0;

    // Find A \ B
    for (int i = 0; i < n; i++) {
        int j;
        for (j = 0; j < m; j++) {
            if (A[i] == B[j]) break;
        }
        if (j == m) {
            resultAminusB[sizeAminusB++] = A[i];
        }
    }

    // Find B \ A
    for (int i = 0; i < m; i++) {
        int j;
        for (j = 0; j < n; j++) {
            if (B[i] == A[j]) break;
        }
        if (j == n) {
            resultBminusA[sizeBminusA++] = B[i];
        }
    }

    printf("Difference A \\ B: ");
    printSet(resultAminusB, sizeAminusB);

    printf("Difference B \\ A: ");
    printSet(resultBminusA, sizeBminusA);
}

// Symmetric difference of two sets
void symmetricDifference(int A[], int n, int B[], int m) {
    int result[MAX_SIZE];
    int size = 0;

    // Find elements in A but not in B
    for (int i = 0; i < n; i++) {
        int j;
        for (j = 0; j < m; j++) {
            if (A[i] == B[j]) break;
        }
        if (j == m) {
            result[size++] = A[i];
        }
    }

    // Find elements in B but not in A
    for (int i = 0; i < m; i++) {
        int j;
        for (j = 0; j < n; j++) {
            if (B[i] == A[j]) break;
        }
        if (j == n) {
            result[size++] = B[i];
        }
    }
    printf("Symmetric Difference of A and B: ");
    printSet(result, size);
}

int main() {
    int n, m;
    int A[MAX_SIZE], B[MAX_SIZE];

    printf("Enter the number of elements in set A: ");
    scanf("%d", &n);
    printf("Enter the elements of set A:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &A[i]);
    }

    printf("Enter the number of elements in set B: ");
    scanf("%d", &m);
    printf("Enter the elements of set B:\n");
    for (int i = 0; i < m; i++) {
        scanf("%d", &B[i]);
    }

    unionSets(A, n, B, m);
    intersectionSets(A, n, B, m);
    setDifference(A, n, B, m);
    symmetricDifference(A, n, B, m);

    return 0;
}