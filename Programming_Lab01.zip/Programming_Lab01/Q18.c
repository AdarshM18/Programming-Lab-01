/* Write a C program to find the frequency of a keyword in a given text file. (Called as “term frequency”.)
Example: Text file contains: “India, officially the Republic of India, is a country in South Asia.”
input keyword: “India”. output: 2. */

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX_WORD_LENGTH 100
#define MAX_LINE_LENGTH 1000

// To convert a string to lowercase
void toLowerCase(char* str) {
    for (int i = 0; str[i]; i++) {
        str[i] = tolower(str[i]);
    }
}

void cleanWord(char* word) {
    char clean[MAX_WORD_LENGTH];
    int j = 0;
    for (int i = 0; word[i]; i++) {
        if (isalpha(word[i])) {
            clean[j++] = tolower(word[i]);
        }
    }
    clean[j] = '\0';
    strcpy(word, clean);
}

int main() {
    char filename[] = "textfile.txt";
    char keyword[MAX_WORD_LENGTH];
    char line[MAX_LINE_LENGTH];
    FILE* file;
    int count = 0;

    printf("Enter the keyword: ");
    scanf("%s", keyword);
    toLowerCase(keyword);

    file = fopen(filename, "r");
    if (file == NULL) {
        printf("Could not open file %s\n", filename);
        return 1;
    }

    while (fgets(line, sizeof(line), file) != NULL) {
        char* word = strtok(line, " ,.-\n");
        while (word != NULL) {
            cleanWord(word);
            if (strcmp(word, keyword) == 0) {
                count++;
            }
            word = strtok(NULL, " ,.-\n");
        }
    }

    fclose(file);

    printf("The keyword '%s' appears %d times in the text file.\n", keyword, count);

    return 0;
}