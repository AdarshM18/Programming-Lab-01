/* The arithmetic sequence 1487,4817 and 8147,in which each of the terms increases by 3330,is unusual in two ways: (i) eachofthethreetermsisprime,and,(ii) each of the 4-digit 
numbers are permutations of one another.There are no arithmetic sequences made up of three 1-,2- or 3-digit primes,exhibiting this property,
but there is one other 4-digit increasing sequence.
What 12-digit number do you form by concatenating the three terms in this sequence ? */

#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>

// To check if a number is prime
bool isPrime(int n) {
    if (n < 2) {
        return false;
    }
    if (n == 2) {
        return true;
    }
    if (n % 2 == 0) {
        return false;
    }
    for (int i = 3; i <= sqrt(n); i += 2) {
        if (n % i == 0) {
            return false;
        }
    }
    return true;
}

// To check if two numbers are permutations of each other
bool arePermutations(int a, int b) {
    char strA[5], strB[5];
    sprintf(strA, "%d", a);
    sprintf(strB, "%d", b);
    int len = strlen(strA);

    if (len != strlen(strB)) {
        return false;
    }

    int countA[10] = {0};
    int countB[10] = {0};

    for (int i = 0; i < len; i++) {
        countA[strA[i] - '0']++;
        countB[strB[i] - '0']++;
    }

    for (int i = 0; i < 10; i++) {
        if (countA[i] != countB[i]) {
            return false;
        }
    }

    return true;
}

// To find the required sequence
void findSequence() {
    for (int a = 1000; a <= 9999; a++) {
        if (isPrime(a)) {
            for (int b = a + 1; b <= 9999; b++) {
                if (isPrime(b) && arePermutations(a, b)) {
                    int c = b + (b - a);
                    if (c <= 9999 && isPrime(c) && arePermutations(a, c)) {
                        printf("Sequence: %d, %d, %d\n", a, b, c);
                        printf("12-digit number: %d%d%d\n", a, b, c);
                        return;
                    }
                }
            }
        }
    }
}
int main() {
    findSequence();
    return 0;
}