/* A number is called an Armstrong number if the sum of the cubes of the digits of the number is equal to the number.
Write a C program that asks the user to enter a number and returns whether it is an Armstrong number.
Example: Input: 153; Output: Armstrong number (i.e., 153 = 13 + 53 + 33) */

#include<stdio.h>

int main(){
    int a;
    int d,cube;
    int cubesum = 0;
    printf("Enter the number: \n");
    scanf("%d",&a);

    int b = a;

    while(b!=0){
        d = b%10;
        cube = d*d*d;
        cubesum = cubesum + cube;
        b = b/10;
    }
    if(a==cubesum){
        printf("%d is an Armstrong Number..",a);
    }
    else{
        printf("%d is not an Armstrong Number..",a);
    }   
}